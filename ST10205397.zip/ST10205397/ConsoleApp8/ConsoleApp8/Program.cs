﻿using System;
//1. The user shall be able to enter the details for a single recipe
namespace RecipeApplication
{
    class Ingredient
    {
        public String name;
        public double quantity;
        public String unit;
    }
    class Recipe
    {
        private Ingredient[] ingredients;
        private String[] steps;
        private int numIngredients;
        private int numsteps;
        public Recipe()
        {
            ingredients= new Ingredient[10]; //start with capacity of 10 Ingredients
            steps= new String[10]; // start with capacity of 10 steps 
            numIngredients= 0;
            numsteps= 0;
        }
        public void AddIgredient(String name, double quantity, String unit)
        {
            if (numIngredients >= ingredients.Length)
            {
                Array.Resize(ref ingredients, ingredients.Length * 2);
                // double the capacity if needed
            }
            Ingredient ingredient = new Ingredient { name = name, quantity = quantity, unit = unit };

            ingredients[numIngredients++] = ingredient;
        }
        public void AddStep(String step) 
        {
             if(numsteps >= steps.Length)
            {
                Array.Resize(ref steps, steps.Length * 2); // double the capacity if needed

            }
            steps[numsteps++] = step;
        }
        // 2. The software shall disply the full recipe, including the ingredints and steps, in a neat format to the user
               public void DisplyRecipe()
        {
            Console.WriteLine("Ingredients:");
                   foreach(Ingredient ingredient in ingredients)
            {
                        if(ingredient != null)
                {
                    Console.WriteLine("-{0} {1} {2}", ingredient.quantity, ingredient.unit, ingredient.name);
                }
            }
            Console.WriteLine("Steps:");
                   for(int i = 0; i < numsteps; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, steps[i]);
            }
        }
        // 3. the user shall be able to request that the recipe is scaled by a factor
        public void ScaleRecipe(double factor)
        {
            foreach(Ingredient ingredient in ingredients)
            {
                if(ingredients != null)
                {
                    ingredient.quantity *= factor;
                }
            }
        }
        // 4. The user can request that the quantities be reset to the original values.
                  public void ResetQuantities()
        {
            foreach(Ingredient ingredient in ingredients)
            {
                if(ingredients != null)
                {
                    ingredient.quantity /= 2; // assuming quantities are scaled up by a factor of 2 unitially
                }
            }
        }
        // 5. The User shall be able to clear all the data to enter a new recipe.
        public void ClearRecipe() 
        {
            ingredients = new Ingredient[10];
                   steps = new string[10];
                   numIngredients= 0;
                   numsteps= 0;
        }
    }
    class program
    {
        private static string igredientUnit;
        private static string step;

        static void Main(string[] args)
        {
            Recipe recipe= new Recipe();
            while (true)
            {
                Console.WriteLine("Enter a comand:addingredint, addstep, display, scale, rest, clear, or exit");
                   String command = Console.ReadLine().ToLower();

                // 6. The software shall not persist the user data between runs.
                                      switch(command)
                {
                    case "addigredients":

                        Console.Write("Enter the ingrediet name:");
                                        String igredientName = Console.ReadLine();
                        Console.Write("Enter the ingrediet quantity:");
                          double igredientQuantity = double.Parse(Console.ReadLine());
                        Console.Write("Enter ingredient unit:"); 
                        Console.ReadLine();
                                        String ingredients = Console.ReadLine();
                        recipe.AddIgredient(igredientName,igredientQuantity,igredientUnit);
                        break;

                    case "addstep":
                        Console.ReadLine();

                        recipe.AddStep(step);
                        break;

                    case "disply":

                        recipe.DisplyRecipe();
                        break;

                    case "scale":
                        Console.Write("Enter Scale factor:");
                                   double factor = double.Parse(Console.ReadLine());
                        recipe.ScaleRecipe(factor);
                        break;

                    case "reset":
                        recipe.ResetQuantities();
                        break;
                   
                    case "clear":
                        recipe.ClearRecipe();
                        break;

                    case "exit":
                        return;
                        default:
                        Console.WriteLine("Invalid command");
                        break;
                }        
            }
        }
    }
}