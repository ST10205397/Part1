﻿using System;
//1. The user shall be able to enter the details for a single recipe

namespace RecipeApp
{
    class Recipe
    {
        public int NumIngredients { get; set; }
        public string[] IngredientsNames { get; set; }
        public double[] IngredientsQuantities { get; set; }
        public String[] IngredinetUnits { get; set; }
        public int NumSteps { get; set; }
        public String[] Steps { get; set; }

        public void DisplayRecipe() 
        {
            Console.WriteLine("Ingredients");
            for (int i = 0; i < NumIngredients; i++)
            {
                Console.WriteLine($"{IngredientsNames[i]} {IngredientsQuantities[i]} {IngredinetUnits[i]} ");

            }
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < NumSteps; i++)
            {
                Console.WriteLine($"{i} {Steps[i]}");

            }
        }
        public void ScaleRecipe(double scale)
        {
            for (int i = 0; i < NumIngredients; i++)
            {
                IngredientsQuantities[i] *= scale;

            }
        }
        public void ResetQuantities()
        {
            // set ingredient quantities back to original value
        }
        public void ClearRecipe() { 
            // reset all recipe data to defult values 
        }
    }
    class program
    {
        public static int NumSteps { get; private set; }

        static void Main(string[] args)
        {
            Recipe recipe= new Recipe();
            // get user input for recipe data

            Console.Write("Enter the Number of ingredients:");
            recipe.NumIngredients= int.Parse(Console.ReadLine());
            recipe.IngredientsNames = new String[recipe.NumIngredients];
            recipe.IngredientsQuantities = new double[recipe.NumIngredients];
            recipe.IngredinetUnits = new string[recipe.NumIngredients];
            for (int i = 0; i < recipe.NumIngredients; i++)
            {
                Console.Write($"Enter the name of the ingredient {i + 1}:");
                recipe.IngredientsNames[i] = Console.ReadLine();

                Console.Write($"Enter the quantity of {recipe.IngredientsNames[i]}:");
                recipe.IngredientsQuantities[i] = double.Parse(Console.ReadLine());
                         
                Console.Write($"Enter the unit of mesurement for {recipe.IngredientsNames[i]}:");
                recipe.IngredinetUnits[i] = Console.ReadLine();


            }
            Console.Write("Enter the number of steps: ");
            recipe.NumSteps= int.Parse(Console.ReadLine()); 
            recipe.Steps = new string[recipe.NumSteps];

            for (int i = 0; i < NumSteps; i++)
            {
                Console.Write($"Enter the step {i + 1}:");
                recipe.Steps[i] = Console.ReadLine();

            }
            // Display the recipe
            Console.WriteLine("\nRecipe:");
            recipe.DisplayRecipe();

            // Scale the recipe by a facor of 2
            recipe.ScaleRecipe(2);
            Console.WriteLine("\nScaled Recipe:");
            recipe.DisplayRecipe();

            // Reset the ingredient quantities to original values 
            recipe.ResetQuantities();
            Console.WriteLine("\nRecipe with origional quantities:");
            recipe.DisplayRecipe();

            // Clear the recipe data
            recipe.ClearRecipe();
            Console.WriteLine("\nRecipe data cleared.");

            Console.ReadLine();
        }
    }
}
